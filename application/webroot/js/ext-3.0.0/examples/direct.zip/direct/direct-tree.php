<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Ext.Direct TreeLoader</title>
    <link rel="stylesheet" type="text/css" href="../../resources/css/ext-all.css" />

    <!-- GC -->
 	<!-- LIBS -->
 	<script type="text/javascript" src="../../adapter/ext/ext-base.js"></script>
 	<!-- ENDLIBS -->

    <script type="text/javascript" src="../../ext-all-debug.js"></script>

    <script language="javascript" src="direct-tree.js"></script>

	<script type="text/javascript" src="php/api.php"></script>
	
    <!-- Common Styles for the examples -->
    <link rel="stylesheet" type="text/css" href="../shared/examples.css" />
</head>
<body>
<!--<script type="text/javascript" src="../shared/examples.js"></script>-->
<!-- EXAMPLES -->

<div id="menu_cadre_arbre" style="border:#000 1px solid; width:240px;height:200px"></div>
</body>
</html>